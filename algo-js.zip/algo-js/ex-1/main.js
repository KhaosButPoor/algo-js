const firstname = "Said";
const lastname = " Mohamed"
let age = 18

alert(firstname)
alert(lastname)
alert(age)