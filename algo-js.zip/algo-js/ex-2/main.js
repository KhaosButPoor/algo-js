let a = 4;
let b = 4;
let c = 3;

if (a == b) {
    console.log("c'est egal")
}

if (c < b && a + c != 3) {
    console.log("ok");
} else {
    console.log("raté");
}