let a = 4;
let b = 4;
let c = 3;

switch (a) {
  case b:
    console.log("égal a b");
    break;
  case c:
    console.log("égal a c");
    break;
  default:
    console.log("rien");
    break;
}
